DEMOS Files
===========

Start and exit files of the toolbox.

.start
-------

It will run a script when loader.sce is run from root toolbox directory. It will run loader files in all of the directories and link to  important library.

.quit
-------

It will run a script when unloader.sce is run from root toolbox directory. It will unlink all of the important libraries.
